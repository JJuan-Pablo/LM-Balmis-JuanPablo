public struct Precio
{
    public decimal Valor { get; }
    public string Moneda { get; }

    public Precio(decimal valor, string moneda)
    {
        Valor = valor;
        Moneda = moneda;
    }
}

public record ColorRGB(byte R, byte G, byte B)
{
    public string ToHex() => $"#{R:X2}{G:X2}{B:X2}";
}

public class ProductoUML
{
    public Guid Id { get; }
    public string Nombre { get; }
    public Precio Precio { get; private set; }

    public ProductoUML(Guid id, string nombre, Precio precio)
    {
        Id = id;
        Nombre = nombre;
        Precio = precio;
    }

    public void ActualizarPrecio(Precio nuevoPrecio) => Precio = nuevoPrecio;
}
