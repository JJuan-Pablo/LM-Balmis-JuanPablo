using System;

class Program
{
    static void Main()
    {
        Precio precio = new Precio(1299.99m, "EUR");
        ProductoUML producto = new ProductoUML(Guid.NewGuid(), "Laptop Gaming", precio);

        ColorRGB color = new ColorRGB(255, 0, 0);

        Console.WriteLine($"Producto: {producto.Nombre} - {producto.Precio.Valor} {producto.Precio.Moneda}");
        Console.WriteLine($"Color RGB: ({color.R}, {color.G}, {color.B}) - Hex: {color.ToHex()}");

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }
}
