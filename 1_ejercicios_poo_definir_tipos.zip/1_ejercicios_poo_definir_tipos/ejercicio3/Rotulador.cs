using System;

public class Rotulador
{
    public enum Color
{
    Rojo,
    Verde,
    Azul,
    Amarillo
}

    private Color color;

    public Rotulador(Color color)
    {
        this.color = color;
    }

    public Color ObtenerColor() => color;

    public void Rotula(float perimetro)
    {
        Console.WriteLine($"Rotulado el perímetro de {perimetro:F2} cm de color {color}.");
    }
}
