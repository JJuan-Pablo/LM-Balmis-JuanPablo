using System;

public class Pincel
{
    public enum Color
{
    Rojo,
    Verde,
    Azul,
    Amarillo
}

    private Color color;

    public void SetColor(Color color)
    {
        this.color = color;
    }

    public void Pinta(float area)
    {
        Console.WriteLine($"Pintada el área de {area:F2} cm² de color {color}.");
    }
}
