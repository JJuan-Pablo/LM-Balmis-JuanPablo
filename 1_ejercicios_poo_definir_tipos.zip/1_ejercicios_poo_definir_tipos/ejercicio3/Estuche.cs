using System;

public static class Estuche
{
    public enum Color
{
    Rojo,
    Verde,
    Azul,
    Amarillo
}

    public const int NUMERO_ROTULADORES = 4;
    private static Rotulador[] rotuladores;

    public static Rotulador[] GetRotuladores()
    {
        if (rotuladores == null)
        {
            Random r = new Random();
            rotuladores = new Rotulador[NUMERO_ROTULADORES];

            for (int i = 0; i < NUMERO_ROTULADORES; i++)
            {
                Color color = (Color)r.Next(0, Enum.GetValues(typeof(Color)).Length);
                rotuladores[i] = new Rotulador(color);
            }
        }
        return rotuladores;
    }
}
