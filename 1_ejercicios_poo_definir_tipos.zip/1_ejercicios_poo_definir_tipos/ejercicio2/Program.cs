﻿using System;

//TODO: Implementar las clases necesarias para la gestión de productos

public class Program
{

    //TODO: Implementar los métodos necesarios para conseguir la lógica pedida


    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 2: Clase Producto con propiedades no autoimplementadas");
        Console.WriteLine();

        //TODO: Implementar la lógica necesaria para gestionar productos

        Console.WriteLine("Pulse cualquier tecla para continuar...");
        Console.ReadKey();
    }
}
