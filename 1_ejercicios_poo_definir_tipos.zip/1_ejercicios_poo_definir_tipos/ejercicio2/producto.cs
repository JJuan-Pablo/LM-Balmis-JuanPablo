using System;
using System.Collections.Generic;

public class Producto
{
    private static List<string> codigosGenerados = new();

    private readonly string _codigo;
    private string _nombre;
    private double _precio;
    private int _stock;

    public Producto(string nombre, double precio, int stock)
    {
        _codigo = GeneraCodigo();
        _nombre = nombre;
        Precio = precio;
        Stock = stock;
    }

    private string GeneraCodigo()
    {
        Random r = new();
        string codigo;
        do
        {
            codigo = $"PR{r.Next(1, 9)}{(char)r.Next(65, 91)}{(char)r.Next(65, 91)}{(char)r.Next(65, 91)}";
        } while (codigosGenerados.Contains(codigo));

        codigosGenerados.Add(codigo);
        return codigo;
    }

    public string Codigo => _codigo;
    public string Nombre => _nombre;

    public double Precio
    {
        get => _precio;
        set => _precio = value > 0 ? value : 20;
    }

    public int Stock
    {
        get => _stock;
        set => _stock = value >= 0 ? value : 1;
    }

    public static string[] CodigosGenerados => codigosGenerados.ToArray();

    public double ValorTotal => Precio * Stock;

    public string Estado =>
        Stock == 0 ? "Sin stock" :
        Stock < 10 ? "Stock bajo" : "En stock";

    public bool Vende(int cantidad)
    {
        if (cantidad <= Stock)
        {
            Stock -= cantidad;
            return true;
        }
        return false;
    }

    public void Repone(int cantidad) => Stock += cantidad;

    public void AplicaDescuento(double porcentaje) =>
        Precio -= Precio * (porcentaje / 100);

    public string ACadena() =>
        $"Código: {Codigo}\nNombre: {Nombre}\nPrecio: {Precio:0.00}€\nStock: {Stock}\nEstado: {Estado}";
}
