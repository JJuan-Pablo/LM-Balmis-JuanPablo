using System;

public class Empleado
{
    public enum Categoria
{
    Subalterno = 10,
    Administrativo = 20,
    JefeDepartamento = 40,
    Gerente = 60
}

    public const double SALARIO_BASE = 1200;

    private readonly string dni;
    private readonly string nombre;
    private readonly int añoNacimiento;
    private Categoria categoria;

    public Empleado(string dni, string nombre, int nacimiento)
    {
        this.dni = dni;
        this.nombre = nombre;
        this.añoNacimiento = nacimiento;
        this.categoria = Categoria.Subalterno;
    }

    public Empleado(Empleado e)
    {
        dni = e.dni;
        nombre = e.nombre;
        añoNacimiento = e.añoNacimiento;
        categoria = e.categoria;
    }

    public string GetDni() => dni;
    public string GetNombre() => nombre;
    public int GetAñoNacimiento() => añoNacimiento;
    public Categoria GetCategoria() => categoria;

    public void SetCategoria(Categoria categoria) => this.categoria = categoria;

    public double Salario() => SALARIO_BASE + SALARIO_BASE * ((int)categoria / 100.0);

    public int CalculaEdad() => DateTime.Now.Year - añoNacimiento;

    public bool TieneMayorSalario(Empleado otro) => Salario() > otro.Salario();

    public bool EsMayorCategoria(Empleado otro) => categoria > otro.categoria;

    public int CalculaDiferenciaEdad(Empleado otro) =>
        Math.Abs(CalculaEdad() - otro.CalculaEdad());

    public string ACadena() =>
        $"DNI: {dni}\nNombre: {nombre}\nAño nacimiento: {añoNacimiento}\nEdad: {CalculaEdad()} años\n" +
        $"Categoría: {categoria}\nSalario: {Salario():0.00}€";
}
