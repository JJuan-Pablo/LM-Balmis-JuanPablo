﻿using System;

class Program
{
public enum Categoria
{
    Subalterno = 10,
    Administrativo = 20,
    JefeDepartamento = 40,
    Gerente = 60
}
    static void Main()
    {
        Console.WriteLine("=== CREACIÓN DE EMPLEADOS ===");

        Console.WriteLine("Introduce datos del primer empleado:");
        Empleado e1 = PideEmpleado();

        Console.WriteLine("Introduce datos del segundo empleado:");
        Empleado e2 = PideEmpleado();

        Console.WriteLine("\n=== INFORMACIÓN DE EMPLEADOS ===");
        Console.WriteLine("--- Empleado 1 ---");
        Console.WriteLine(e1.ACadena());

        Console.WriteLine("\n--- Empleado 2 ---");
        Console.WriteLine(e2.ACadena());

        Console.WriteLine("\n=== PROMOCIONES Y CAMBIOS ===");
        Console.WriteLine($"Promocionando a {e1.GetNombre()} a JefeDepartamento...");
        e1.SetCategoria(Categoria.JefeDepartamento);

        Console.WriteLine($"Promocionando a {e2.GetNombre()} a Gerente...");
        e2.SetCategoria(Categoria.Gerente);

        Console.WriteLine("\n--- Estado después de promociones ---");
        Console.WriteLine("Empleado 1:");
        Console.WriteLine(e1.ACadena());

        Console.WriteLine("\nEmpleado 2:");
        Console.WriteLine(e2.ACadena());

        Console.WriteLine("\n=== CREACIÓN DE COPIA ===");
        Console.WriteLine($"Creando copia de {e1.GetNombre()}...");
        Empleado copia = new Empleado(e1);
        Console.WriteLine("Empleado copiado:");
        Console.WriteLine(copia.ACadena());

        Console.WriteLine("\n=== COMPARACIONES ===");
        Console.WriteLine($"¿{e1.GetNombre()} tiene mayor salario que {e2.GetNombre()}? {e1.TieneMayorSalario(e2)}");
        Console.WriteLine($"¿{e2.GetNombre()} es de mayor categoría que {e1.GetNombre()}? {e2.EsMayorCategoria(e1)}");
        Console.WriteLine($"Diferencia de edad: {e1.CalculaDiferenciaEdad(e2)} años");

        Console.WriteLine("\nPresiona cualquier tecla para salir...");
        Console.ReadKey();
    }

    static Empleado PideEmpleado()
    {
        Console.Write("DNI: ");
        string dni = Console.ReadLine();

        Console.Write("Nombre: ");
        string nombre = Console.ReadLine();

        Console.Write("Año de nacimiento: ");
        int nacimiento;
        while (!int.TryParse(Console.ReadLine(), out nacimiento))
        {
            Console.Write("Año inválido. Introduce un número: ");
        }

        Console.WriteLine("Categorías disponibles: " +
            string.Join(", ", Enum.GetNames(typeof(Categoria))));

        Console.Write("Categoría: ");
        string texto = Console.ReadLine();

        Empleado e = new Empleado(dni, nombre, nacimiento);
        e.SetCategoria(ParseaCategoria(texto));

        return e;
    }

    static Categoria ParseaCategoria(string texto)
    {
        if (int.TryParse(texto, out int valor))
        {
            if (Enum.IsDefined(typeof(Categoria), valor))
                return (Categoria)valor;
        }

        if (Enum.TryParse(texto, true, out Categoria cat))
            return cat;

        return Categoria.Subalterno;
    }
}
